import React from "react";

const Footer=()=>{

    return(
        <div className="footer">
            <h3>Mead Search Dash board</h3>
        </div>
    )

}

export default Footer;